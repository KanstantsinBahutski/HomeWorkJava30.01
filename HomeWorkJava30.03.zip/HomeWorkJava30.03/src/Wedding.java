public enum Wedding {
    ONEYEAR ("Ситцевая (марлевая) свадьба"),
    TWOYEARS ("Бумажная свадьба"),
    THREEYEARS ("Кожаная свадьба"),
    FOURYEARS ("Льняная свадьба"),
    FIVEYEARS ("Деревянная свадьба"),
    SIXYEARS ("Чугунная свадьба"),
    SEVENYEARS ("Медная (Шерстяная) свадьба"),
    EIGHTYEARS ("Жестяная свадьба"),
    NINEYEARS ("Фаянсовая (ромашковая) свадьба"),
    TENYEARS ("Оловянная свадьба"),
    ELEVENYEARS ("Стальная свадьба"),
    TWELVEYEARS ("Никелевая свадьба");


    private final String description;

    public String getDescription() {
        return description;
    }

    Wedding(String description){
        this.description = description;
    }
}
