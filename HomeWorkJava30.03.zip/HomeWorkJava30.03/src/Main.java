import java.util.Scanner;

public class Main {

    //Пользователь вводит, сколько лет он состоит в браке.
    // Программа должна вывести, какая годовщина свадьбы будет у пользователя следующей
    // (бумажная, ситцевая, чугунная, серебряная и.д.). Не обязательно указывать все годовщины, достаточно 10-15.
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите сколько лет состоите в браке:");
        int wedNum = scn.nextInt();
        String message = switch (wedNum){
            case 0 -> concat(Wedding.ONEYEAR);
            case 1 -> concat(Wedding.TWOYEARS);
            case 2 -> concat(Wedding.THREEYEARS);
            case 3 -> concat(Wedding.FOURYEARS);
            case 4 -> concat(Wedding.FIVEYEARS);
            case 5 -> concat(Wedding.SIXYEARS);
            case 6 -> concat(Wedding.SEVENYEARS);
            case 7 -> concat(Wedding.EIGHTYEARS);
            case 8 -> concat(Wedding.NINEYEARS);
            case 9 -> concat(Wedding.TENYEARS);
            case 10 -> concat(Wedding.ELEVENYEARS);
            case 11 -> concat(Wedding.TWELVEYEARS);
            default -> "O_o too much";
        };
        System.out.println("Следующая годовщина " + message);
    }
    private static String concat(Wedding wed){
        return wed.name() + ": " + wed.getDescription();
    }
}